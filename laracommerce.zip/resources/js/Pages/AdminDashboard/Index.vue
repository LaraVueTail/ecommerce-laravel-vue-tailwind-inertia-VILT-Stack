<template>
    <h1 class="text-xl font-medium text-gray-600">Welcome {{ $page.props.auth.firstName }}</h1>
</template>
<script>
</script>